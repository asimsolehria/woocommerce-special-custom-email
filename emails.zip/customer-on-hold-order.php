<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "https://www.w3.org/TR/html4/strict.dtd">
<html lang="en">

<head>
    <meta http-equiv=Content-Type content="text/html; charset=UTF-8">
    <style type="text/css" nonce="OFV2Jvom/N0dzbe+UPJX4g">
        body,
        td,
        div,
        p,
        a,
        input {
            font-family: arial, sans-serif;
        }
    </style>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="https://ssl.gstatic.com/ui/v1/icons/mail/rfr/gmail.ico" type="image/x-icon">
    <title></title>
    <style type="text/css" nonce="OFV2Jvom/N0dzbe+UPJX4g">
        body,
        td {
            font-size: 13px
        }

        a:link,
        a:active {
            color: #1155CC;
            text-decoration: none
        }

        a:hover {
            text-decoration: underline;
            cursor: pointer
        }

        a:visited {
            color: ##6611CC
        }

        img {
            border: 0px
        }

        pre {
            white-space: pre;
            white-space: -moz-pre-wrap;
            white-space: -o-pre-wrap;
            white-space: pre-wrap;
            word-wrap: break-word;
            max-width: 800px;
            overflow: auto;
        }

        .logo {
            left: -7px;
            position: relative;
        }
    </style>

<body>
    <div class="bodycontainer">
        <div class="maincontent">
            <table width=100% cellpadding=0 cellspacing=0 border=0 class="message">
                <tr>
                    
                <tr>
                    <td colspan=2>
                        <table width=100% cellpadding=12 cellspacing=0 border=0>
                            <tr>
                                <td>
                                    <div style="overflow: hidden;">
                                        <font size=-1>
                                            <div>
                                                <div id="m_7866393457056888844ydpf922b39dyahoo_quoted_7632959596">
                                                    <div>
                                                        <div>
                                                            <div id="m_7866393457056888844ydpf922b39dyiv4660054999">
                                                                <div>
                                                                    <div>
                                                                        <div>
                                                                            <div dir="ltr">
                                                                                <div>
                                                                                    <div style="margin:0px;padding:0px">
                                                                                        <table width="100%"
                                                                                            cellspacing="0"
                                                                                            cellpadding="0" border="0">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td width="100%"
                                                                                                        bgcolor="#F5F5F5"
                                                                                                        align="center">
                                                                                                        <table
                                                                                                            style="width:640px;min-width:640px"
                                                                                                            width="640"
                                                                                                            cellspacing="0"
                                                                                                            cellpadding="0"
                                                                                                            border="0">
                                                                                                            <tbody>
                                                                                                                <tr>
                                                                                                                    <td style="width:640px;min-width:640px"
                                                                                                                        width="640"
                                                                                                                        align="center">
                                                                                                                        
                                                                                                                        <table
                                                                                                                            width="100%"
                                                                                                                            cellspacing="0"
                                                                                                                            cellpadding="0"
                                                                                                                            border="0">
                                                                                                                            <tbody>
                                                                                                                                <tr>
                                                                                                                                    <td style="padding:30px 40px 30px 40px"
                                                                                                                                        align="center">
                                                                                                                                        <table
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="0"
                                                                                                                                            border="0"
                                                                                                                                            align="center">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td valign="top"
                                                                                                                                                        align="center">
                                                                                                                                                        <a href="<?php echo bloginfo("home"); ?>"><img
                                                                                                                                                                src="https://hive.gg/wp-content/uploads/2020/09/Primary_Logo_Without_text.png"
                                                                                                                                                                alt="logo_Name"
                                                                                                                                                                style="display:block;width:140px;max-width:140px"
                                                                                                                                                                border="0"></a>
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                            </tbody>
                                                                                                                        </table>
                                                                                                                        <table
                                                                                                                            width="100%"
                                                                                                                            cellspacing="0"
                                                                                                                            cellpadding="0"
                                                                                                                            border="0"
                                                                                                                            bgcolor="#ffffff">
                                                                                                                            <tbody>
                                                                                                                                <tr>
                                                                                                                                    <td style="padding:40px 40px 40px 40px"
                                                                                                                                        align="left">
                                                                                                                                        <table
                                                                                                                                            width="100%"
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="0"
                                                                                                                                            border="0">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
																																					<td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;color:#2f3132;font-size:36px;line-height:40px;letter-spacing:-1px;font-weight:bold;padding:0px 0px 30px 0px;
																																					text-transform: uppercase;
																																					"
                                                                                                                                                        valign="top"
                                                                                                                                                        align="center">
																																						
																																						<?php echo $order->get_billing_first_name(); ?>,<br>YOUR ORDER IS RECIEVED
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                                <tr>
                                                                                                                                                    <td style="padding:0px 0px 30px 0px"
                                                                                                                                                        align="center">
                                                                                                                                                        <table
                                                                                                                                                            cellspacing="0"
                                                                                                                                                            cellpadding="0"
                                                                                                                                                            border="0">
                                                                                                                                                            <tbody>
                                                                                                                                                                <tr>
                                                                                                                                                                    <td valign="middle"
                                                                                                                                                                        align="center">
                                                                                                                                                                        <img src="https://hive.gg/wp-content/uploads/2020/12/shopping-chart-blue.png"
                                                                                                                                                                            alt=""
                                                                                                                                                                            style="display:block"
                                                                                                                                                                            width="33">
                                                                                                                                                                    </td>
                                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;color:#bfbfbf;font-size:22px;padding:0px 12px 0px 12px"
                                                                                                                                                                        valign="middle"
                                                                                                                                                                        align="center">
                                                                                                                                                                        –
                                                                                                                                                                    </td>
                                                                                                                                                                    <td valign="middle"
                                                                                                                                                                        align="center">
                                                                                                                                                                        <img src="https://hive.gg/wp-content/uploads/2020/12/card-grey.png"
                                                                                                                                                                            alt=""
                                                                                                                                                                            style="display:block"
                                                                                                                                                                            width="31">
                                                                                                                                                                    </td>
                                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;color:#bfbfbf;font-size:22px;padding:0px 12px 0px 12px"
                                                                                                                                                                        valign="middle"
                                                                                                                                                                        align="center">
                                                                                                                                                                        –
                                                                                                                                                                    </td>
                                                                                                                                                                    <td valign="middle"
                                                                                                                                                                        align="center">
                                                                                                                                                                        <img src="https://hive.gg/wp-content/uploads/2020/12/box-car-grey.png"
                                                                                                                                                                            alt=""
                                                                                                                                                                            style="display:block"
                                                                                                                                                                            width="39">
                                                                                                                                                                    </td>
                                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;color:#bfbfbf;font-size:22px;padding:0px 12px 0px 12px"
                                                                                                                                                                        valign="middle"
                                                                                                                                                                        align="center">
                                                                                                                                                                        –
                                                                                                                                                                    </td>
                                                                                                                                                                    <td valign="middle"
                                                                                                                                                                        align="center">
                                                                                                                                                                        <img src="https://hive.gg/wp-content/uploads/2020/12/box-grey.png"
                                                                                                                                                                            alt=""
                                                                                                                                                                            style="display:block"
                                                                                                                                                                            width="33">
                                                                                                                                                                    </td>
                                                                                                                                                                </tr>
                                                                                                                                                            </tbody>
                                                                                                                                                        </table>
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                                <tr>
                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;color:#2f3132;font-size:16px;line-height:20px"
                                                                                                                                                        valign="top"
                                                                                                                                                        align="center">
                                                                                                                                                        Thanks for your order. It’s on-hold until we confirm that payment has been received. In the meantime, here’s a reminder of what you ordered:
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                                <tr>
                                                                                                                                    <td style="padding:0px 40px 0px 40px"
                                                                                                                                        align="center">
                                                                                                                                        <table
                                                                                                                                            width="100%"
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="0"
                                                                                                                                            border="0"
                                                                                                                                            bgcolor="#C3C6C8">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td style="font-size:1px;line-height:1px"
                                                                                                                                                        height="1">
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                                <tr>
                                                                                                                                    <td style="padding:30px 40px 30px 40px"
                                                                                                                                        align="center">
                                                                                                                                        <table
                                                                                                                                            style="display:inline"
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="0"
                                                                                                                                            border="0"
                                                                                                                                            align="left">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;color:#2f3132;font-size:13px;line-height:15px;font-weight:normal;padding:0px 0px 6px 0px"
                                                                                                                                                        align="left">
                                                                                                                                                        <span
                                                                                                                                                            style="font-weight:bold">Purchase
                                                                                                                                                            date:</span>
																																							<?php echo $order->get_date_created()->format('F d Y'); ?>
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                                <tr>
                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;color:#2f3132;font-size:13px;line-height:15px;font-weight:normal;padding:0px 0px 6px 0px"
                                                                                                                                                        align="left">
                                                                                                                                                        <span
                                                                                                                                                            style="font-weight:bold">Order
                                                                                                                                                            #</span>
																																							<?php echo sprintf(__('%s', 'woocomemrce'), $order->get_order_number()); ?>
                                                                                                                                                    </td>
																																				</tr>
                                                                                                                                                <tr>
                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;color:#2f3132;font-size:13px;line-height:15px;font-weight:normal;padding:0px 0px 6px 0px"
                                                                                                                                                        align="left">
                                                                                                                                                        <span
                                                                                                                                                            style="font-weight:bold">Guest Access Code:
                                                                                                                                                        	</span>
                                                                                                                                                        59Um526y
                                                                                                                                                    </td>
																																				</tr>

                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                        <table
                                                                                                                                            style="display:inline"
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="0"
                                                                                                                                            border="0"
                                                                                                                                            align="right">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td
                                                                                                                                                        align="center">
                                                                                                                                                        <table
                                                                                                                                                            cellspacing="0"
                                                                                                                                                            cellpadding="0"
                                                                                                                                                            border="0">
                                                                                                                                                            <tbody>
                                                                                                                                                                <tr>


																																								<?php $order_url = $sent_to_admin ? $order->get_edit_order_url() : $order->get_view_order_url(); ?>
																																								
																																										
																																							


                                                                                                                                                                    <td bgcolor="#007dba"
                                                                                                                                                                        align="c">
																																										<a href="
																																										<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>
																																										"
                                                                                                                                                                            style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;padding:19px 36px;border:2px solid #007dba;color:#ffffff;display:inline-block;font-size:13px;font-weight:bold;text-decoration:none"
                                                                                                                                                                            rel="noreferrer noopener"
																																											>SEE YOUR ACCOUNT</a>
																																										
																																									</td>
																																									
																																								</tr>
																																								
																																							</tbody>
																																							
																																						</table>
																																						<span style=""><a style="font-size: .8em; letter-spacing: -.03em; padding-top: 10px;" href="<?php echo esc_url($order_url); ?>">Don't have an account? Look up your order here.</a></span>
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                                <tr>
                                                                                                                                    <td style="padding:0px 40px 0px 40px"
                                                                                                                                        align="center">
                                                                                                                                        <table
                                                                                                                                            width="100%"
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="0"
                                                                                                                                            border="0"
                                                                                                                                            bgcolor="#C3C6C8">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td style="font-size:1px;line-height:1px"
                                                                                                                                                        height="1">
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                                <tr>
                                                                                                                                    <td style="padding:15px 40px 10px 40px;font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif"
                                                                                                                                        align="center">
                                                                                                                                        
                                                                                                                                        <table
                                                                                                                                            width="100%"
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="0"
                                                                                                                                            border="0"
                                                                                                                                            bgcolor="">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td style="font-size:1px;line-height:1px"
                                                                                                                                                        height="1">
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                        <table
                                                                                                                                            width="100%"
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="5"
                                                                                                                                            bgcolor="#FFFFFF">
																																		   
																																			





<?php
    echo wc_get_email_order_items($order, array(
        'show_sku' => $sent_to_admin,
        'show_image' => true,
        'image_size' => array(100, 100),
        'plain_text' => $plain_text,
        'sent_to_admin' => $sent_to_admin,
    ));
?>







                                                                                                                                        </table>
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                                <tr>
                                                                                                                                    <td style="padding:0px 40px 0px 40px"
                                                                                                                                        align="center">
                                                                                                                                        <table
                                                                                                                                            width="100%"
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="0"
                                                                                                                                            border="0"
                                                                                                                                            bgcolor="#C3C6C8">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td style="font-size:1px;line-height:1px"
                                                                                                                                                        height="1">
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                                <tr>
                                                                                                                                    <td style="padding:40px 40px 40px 40px"
                                                                                                                                        align="center">
                                                                                                                                        <table
                                                                                                                                            width="100%"
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="0"
                                                                                                                                            border="0"
                                                                                                                                            align="left">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;font-size:14px;line-height:18px;color:#2f3132;text-align:right;padding:0px 0px 10px 0px"
                                                                                                                                                        valign="middle"
                                                                                                                                                        align="right">
                                                                                                                                                        Subtotal
                                                                                                                                                    </td>
                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;font-size:16px;line-height:20px;color:#2f3132;text-align:right;width:130px;padding:0px 0px 10px 0px"
                                                                                                                                                        width="130"
                                                                                                                                                        align="right">
                                                                                                                                                        $<?php echo $order->get_subtotal(); ?>
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                                <tr>
                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;font-size:14px;line-height:18px;color:#2f3132;text-align:right;padding:0px 0px 10px 0px"
                                                                                                                                                        valign="middle"
                                                                                                                                                        align="right">
                                                                                                                                                        Discount(s)
                                                                                                                                                    </td>
                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;font-size:16px;line-height:20px;color:#2f3132;text-align:right;width:130px;padding:0px 0px 10px 0px"
                                                                                                                                                        width="130"
                                                                                                                                                        align="right">
                                                                                                                                                        <?php echo $order->get_discount_to_display(); ?>
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                                <tr>
                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;font-size:14px;line-height:18px;color:#2f3132;text-align:right;padding:0px 0px 10px 0px"
                                                                                                                                                        valign="middle"
                                                                                                                                                        align="right">
                                                                                                                                                        Tax
                                                                                                                                                    </td>
                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;font-size:16px;line-height:20px;color:#2f3132;text-align:right;width:130px;padding:0px 0px 10px 0px"
                                                                                                                                                        width="130"
                                                                                                                                                        align="right">
                                                                                                                                                        $<?php echo $order->get_total_tax(); ?>
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                                <tr>
                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;font-size:14px;line-height:18px;color:#2f3132;text-align:right"
                                                                                                                                                        valign="middle"
                                                                                                                                                        align="right">
                                                                                                                                                        Shipping
                                                                                                                                                    </td>
                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;font-size:16px;line-height:20px;color:#2f3132;text-align:right;width:130px"
                                                                                                                                                        width="130"
                                                                                                                                                        align="right">
                                                                                                                                                        $<?php echo $order->get_shipping_total(); ?>
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                                <tr>
                                                                                                                                    <td style="padding:0px 40px 0px 40px"
                                                                                                                                        align="center">
                                                                                                                                        <table
                                                                                                                                            width="100%"
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="0"
                                                                                                                                            border="0"
                                                                                                                                            bgcolor="#C3C6C8">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td style="font-size:1px;line-height:1px"
                                                                                                                                                        height="1">
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                                <tr>
                                                                                                                                    <td style="padding:20px 40px 20px 40px"
                                                                                                                                        align="center">
                                                                                                                                        <table
                                                                                                                                            width="100%"
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="0"
                                                                                                                                            border="0"
                                                                                                                                            align="left">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;font-size:14px;line-height:18px;color:#2f3132;font-weight:bold;text-align:right"
                                                                                                                                                        valign="middle"
                                                                                                                                                        align="right">
                                                                                                                                                        Total
                                                                                                                                                    </td>
                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;font-size:16px;line-height:20px;color:#2f3132;font-weight:bold;text-align:right;width:130px"
                                                                                                                                                        width="130"
                                                                                                                                                        align="right">
                                                                                                                                                        $<?php echo $order->get_total(); ?>
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                            </tbody>
                                                                                                                        </table>
                                                                                                                        <table
                                                                                                                            width="100%"
                                                                                                                            cellspacing="0"
                                                                                                                            cellpadding="0"
                                                                                                                            border="0"
                                                                                                                            bgcolor="#ffffff">
                                                                                                                            <tbody>
                                                                                                                                <tr>
                                                                                                                                    <td style="padding:0px 40px 0px 40px"
                                                                                                                                        align="center">
                                                                                                                                        <table
                                                                                                                                            width="100%"
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="0"
                                                                                                                                            border="0"
                                                                                                                                            bgcolor="#C3C6C8">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td style="font-size:1px;line-height:1px"
                                                                                                                                                        height="1">
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                            </tbody>
                                                                                                                        </table>
                                                                                                                        <table
                                                                                                                            width="100%"
                                                                                                                            cellspacing="0"
                                                                                                                            cellpadding="0"
                                                                                                                            border="0"
                                                                                                                            bgcolor="#ffffff">
                                                                                                                            <tbody>
                                                                                                                                <tr>
                                                                                                                                    <td style="padding:30px 40px 30px 40px"
                                                                                                                                        align="center">
                                                                                                                                        <table
                                                                                                                                            style="border:1px solid #c3c6c8"
                                                                                                                                            width="100%"
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="0"
                                                                                                                                            border="0">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td style="padding:20px 20px 20px 20px"
                                                                                                                                                        align="center">
                                                                                                                                                        <table
                                                                                                                                                            style="display:inline;width:250px"
                                                                                                                                                            width="250"
                                                                                                                                                            cellspacing="0"
                                                                                                                                                            cellpadding="0"
                                                                                                                                                            border="0"
                                                                                                                                                            align="left">
                                                                                                                                                            <tbody>
                                                                                                                                                                <tr>
                                                                                                                                                                    <td valign="top"
                                                                                                                                                                        align="left">
                                                                                                                                                                        <table
                                                                                                                                                                            style="display:inline;width:100px"
                                                                                                                                                                            width="100"
                                                                                                                                                                            cellspacing="0"
                                                                                                                                                                            cellpadding="0"
                                                                                                                                                                            border="0"
                                                                                                                                                                            align="left">
                                                                                                                                                                            <tbody>
                                                                                                                                                                                <tr>
                                                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;font-size:16px;line-height:20px;color:#2f3132;font-weight:bold;white-space:nowrap"
                                                                                                                                                                                        valign="top"
                                                                                                                                                                                        align="left">
                                                                                                                                                                                        Shipped
                                                                                                                                                                                        to
                                                                                                                                                                                    </td>
                                                                                                                                                                                </tr>
                                                                                                                                                                            </tbody>
                                                                                                                                                                        </table>
                                                                                                                                                                        <table
                                                                                                                                                                            style="display:inline;width:150px"
                                                                                                                                                                            width="150"
                                                                                                                                                                            cellspacing="0"
                                                                                                                                                                            cellpadding="0"
                                                                                                                                                                            border="0"
                                                                                                                                                                            align="right">
                                                                                                                                                                            <tbody>
                                                                                                                                                                                <tr>
                                                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;font-size:14px;line-height:18px;color:#2f3132"
                                                                                                                                                                                        valign="top"
                                                                                                                                                                                        align="left">
                                                                                                                                                                                        <?php echo $order->get_shipping_first_name(); ?>
                                                                                                                                                                                        <?php echo $order->get_shipping_last_name(); ?><br><br>
                                                                                                                                                                                    </td>
                                                                                                                                                                                </tr>
                                                                                                                                                                            </tbody>
                                                                                                                                                                        </table>
                                                                                                                                                                    </td>
                                                                                                                                                                </tr>
                                                                                                                                                            </tbody>
                                                                                                                                                        </table>
                                                                                                                                                        <table
                                                                                                                                                            style="width:250px"
                                                                                                                                                            width="250"
                                                                                                                                                            cellspacing="0"
                                                                                                                                                            cellpadding="0"
                                                                                                                                                            border="0"
                                                                                                                                                            align="right">
                                                                                                                                                            <tbody>
                                                                                                                                                                <tr>
                                                                                                                                                                    <td valign="top"
                                                                                                                                                                        align="left">
                                                                                                                                                                        <table
                                                                                                                                                                            style="display:inline;width:100px"
                                                                                                                                                                            width="100"
                                                                                                                                                                            cellspacing="0"
                                                                                                                                                                            cellpadding="0"
                                                                                                                                                                            border="0"
                                                                                                                                                                            align="left">
                                                                                                                                                                            <tbody>
                                                                                                                                                                                <tr>
                                                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;font-size:16px;line-height:20px;color:#2f3132;font-weight:bold;white-space:nowrap"
                                                                                                                                                                                        valign="top"
                                                                                                                                                                                        align="left">
                                                                                                                                                                                        Billed
                                                                                                                                                                                        to
                                                                                                                                                                                    </td>
                                                                                                                                                                                </tr>
                                                                                                                                                                            </tbody>
                                                                                                                                                                        </table>
                                                                                                                                                                        <table
                                                                                                                                                                            style="display:inline;width:150px"
                                                                                                                                                                            width="150"
                                                                                                                                                                            cellspacing="0"
                                                                                                                                                                            cellpadding="0"
                                                                                                                                                                            border="0"
                                                                                                                                                                            align="right">
                                                                                                                                                                            <tbody>
                                                                                                                                                                                <tr>
                                                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;font-size:14px;line-height:18px;color:#2f3132"
                                                                                                                                                                                        valign="top"
                                                                                                                                                                                        align="left">
                                                                                                                                                                                        <?php echo $order->get_billing_first_name(); ?>
                                                                                                                                                                                        <?php echo $order->get_billing_last_name(); ?><br><br>
                                                                                                                                                                                    </td>
                                                                                                                                                                                </tr>
                                                                                                                                                                            </tbody>
                                                                                                                                                                        </table>
                                                                                                                                                                    </td>
                                                                                                                                                                </tr>
                                                                                                                                                            </tbody>
                                                                                                                                                        </table>
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                            </tbody>
                                                                                                                        </table>
                                                                                                                        <table
                                                                                                                            width="100%"
                                                                                                                            cellspacing="0"
                                                                                                                            cellpadding="0"
                                                                                                                            border="0"
                                                                                                                            bgcolor="#f68d2e">
                                                                                                                            <tbody>
                                                                                                                                <tr>
                                                                                                                                    <td style="padding:20px 40px 20px 40px"
                                                                                                                                        align="center">
                                                                                                                                        <table
                                                                                                                                            style="display:inline;width:364px"
                                                                                                                                            width="364"
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="0"
                                                                                                                                            border="0"
                                                                                                                                            align="left">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td
                                                                                                                                                        align="left">
                                                                                                                                                        <table
                                                                                                                                                            style="display:inline;width:80px"
                                                                                                                                                            width="80"
                                                                                                                                                            cellspacing="0"
                                                                                                                                                            cellpadding="0"
                                                                                                                                                            border="0"
                                                                                                                                                            align="left">
                                                                                                                                                            <tbody>
                                                                                                                                                                <tr>
                                                                                                                                                                    <td style="padding:5px 35px 0px 0px"
                                                                                                                                                                        valign="middle"
                                                                                                                                                                        align="center">
                                                                                                                                                                        <a href="#m_7866393457056888844_m_-2492978437468248781_m_3131581504716965371_"
                                                                                                                                                                            rel="noreferrer noopener"><img
                                                                                                                                                                                src="https://ci3.googleusercontent.com/proxy/D9dGDhdgZMEYAQM32FwyAmiAbpBCOzxaptMNJXtBpd5Fu8SHWb52vwGqFeNq3bLcYykLtTbVRtracbjAa1hOiFRuqH951w9xO9wHrGXc2NWNSCx2i93ylYwcfjISwNhT2-oPJiimZiVw2idGW_X4nv73ICi2Ckf9jOWoFNs9VTS4CzZq=s0-d-e1-ft#https://drh.img.digitalriver.com/DRHM/Storefront/Site/logib2c/pb/images/notifications2019/icon_question_white.png"
                                                                                                                                                                                alt=""
                                                                                                                                                                                style="display:block"
                                                                                                                                                                                width="45"
                                                                                                                                                                                border="0"></a>
                                                                                                                                                                    </td>
                                                                                                                                                                </tr>
                                                                                                                                                            </tbody>
                                                                                                                                                        </table>
                                                                                                                                                        <table
                                                                                                                                                            style="display:inline;width:280px"
                                                                                                                                                            width="280"
                                                                                                                                                            cellspacing="0"
                                                                                                                                                            cellpadding="0"
                                                                                                                                                            border="0"
                                                                                                                                                            align="left">
                                                                                                                                                            <tbody>
                                                                                                                                                                <tr>
                                                                                                                                                                    <td style="padding:12px 0px 0px 0px"
                                                                                                                                                                        align="left">
                                                                                                                                                                        <table
                                                                                                                                                                            style="display:inline"
                                                                                                                                                                            cellspacing="0"
                                                                                                                                                                            cellpadding="0"
                                                                                                                                                                            border="0"
                                                                                                                                                                            align="left">
                                                                                                                                                                            <tbody>
                                                                                                                                                                                <tr>
                                                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;color:#ffffff;font-size:24px;line-height:28px;font-weight:bold;padding:0px 8px 0px 0px"
                                                                                                                                                                                        align="left">
                                                                                                                                                                                        Questions?
                                                                                                                                                                                    </td>
                                                                                                                                                                                </tr>
                                                                                                                                                                            </tbody>
                                                                                                                                                                        </table>
                                                                                                                                                                        <table
                                                                                                                                                                            style="display:inline"
                                                                                                                                                                            cellspacing="0"
                                                                                                                                                                            cellpadding="0"
                                                                                                                                                                            border="0"
                                                                                                                                                                            align="left">
                                                                                                                                                                            <tbody>
                                                                                                                                                                                <tr>
                                                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;color:#ffffff;font-size:16px;line-height:20px;padding:6px 0px 0px 0px"
                                                                                                                                                                                        align="left">
                                                                                                                                                                                        We&#39;re
                                                                                                                                                                                        here
                                                                                                                                                                                        to
                                                                                                                                                                                        help
                                                                                                                                                                                    </td>
                                                                                                                                                                                </tr>
                                                                                                                                                                            </tbody>
                                                                                                                                                                        </table>
                                                                                                                                                                    </td>
                                                                                                                                                                </tr>
                                                                                                                                                            </tbody>
                                                                                                                                                        </table>
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                        <table
                                                                                                                                            style="width:176px"
                                                                                                                                            width="176"
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="0"
                                                                                                                                            border="0"
                                                                                                                                            align="right">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td valign="top"
                                                                                                                                                        align="right">
                                                                                                                                                        <table
                                                                                                                                                            cellspacing="0"
                                                                                                                                                            cellpadding="0"
                                                                                                                                                            border="0">
                                                                                                                                                            <tbody>
                                                                                                                                                                <tr>
                                                                                                                                                                    <td
                                                                                                                                                                        align="center">
                                                                                                                                                                        <a href="https://hive.gg/contact-us/"
                                                                                                                                                                            style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;padding:19px 32px;border:2px solid #ffffff;display:inline-block;font-size:13px;color:#ffffff;font-weight:bold;text-decoration:none;white-space:nowrap"
                                                                                                                                                                            rel="noreferrer noopener"
                                                                                                                                                                            target="_blank"
                                                                                                                                                                            data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=http://www.astrogaming.com/support&amp;source=gmail&amp;ust=1607422678059000&amp;usg=AFQjCNHxQ_pD8wIORGdFKuAEqfM3_p32ow">SUPPORT</a>
                                                                                                                                                                    </td>
                                                                                                                                                                </tr>
                                                                                                                                                            </tbody>
                                                                                                                                                        </table>
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                            </tbody>
                                                                                                                        </table>
                                                                                                                        <table
                                                                                                                            width="100%"
                                                                                                                            cellspacing="0"
                                                                                                                            cellpadding="0"
                                                                                                                            border="0">
                                                                                                                            <tbody>
                                                                                                                                <tr>
                                                                                                                                    <td style="font-size:1px;line-height:1px"
                                                                                                                                        height="16">
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                            </tbody>
                                                                                                                        </table>
                                                                                                                        <table
                                                                                                                            width="100%"
                                                                                                                            cellspacing="0"
                                                                                                                            cellpadding="0"
                                                                                                                            border="0"
                                                                                                                            bgcolor="#ffffff">
                                                                                                                            <tbody>
                                                                                                                                <tr>
                                                                                                                                    <td style="padding:25px 40px 25px 40px"
                                                                                                                                        valign="middle"
                                                                                                                                        align="center">
                                                                                                                                        <table
                                                                                                                                            style="width:345px"
                                                                                                                                            width="345"
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="0"
                                                                                                                                            border="0">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td valign="middle"
                                                                                                                                                        align="center">
                                                                                                                                                        <table
                                                                                                                                                            width="100%"
                                                                                                                                                            cellspacing="0"
                                                                                                                                                            cellpadding="0"
                                                                                                                                                            border="0">
                                                                                                                                                            <tbody>
                                                                                                                                                                <tr>
                                                                                                                                                                    <td width="20%"
                                                                                                                                                                        valign="middle"
                                                                                                                                                                        align="center">
                                                                                                                                                                        <a href="https://www.facebook.com/ESPORTSHIVE/"
                                                                                                                                                                            rel="noreferrer noopener"
                                                                                                                                                                            target="_blank"
                                                                                                                                                                            data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=http://astrogaming.com/facebook&amp;source=gmail&amp;ust=1607422678059000&amp;usg=AFQjCNHTj3GijvpdqGMLYLXeO4iHeH0p-Q"><img
                                                                                                                                                                                src="https://ci3.googleusercontent.com/proxy/T5YYryKwextGzddWBMN7W8XBEclFOX8KG-M3TszlWMZu4eSwalzHdzhiwu-xk4g7AjyKYa0zw9hLUR4x3SlvTUSiGgiDuBXu49vySpRTmDzKTCHHbS1uUh3FJ2MIgrVVWWLaC6B_9lq-jCmIqk4EB38TdmbjDXLfNcg=s0-d-e1-ft#https://drh.img.digitalriver.com/DRHM/Storefront/Site/logib2c/pb/images/notifications2019/fb_icon_b.png"
                                                                                                                                                                                alt="Facebook"
                                                                                                                                                                                style="display:block"
                                                                                                                                                                                width="12"
                                                                                                                                                                                border="0"></a>
                                                                                                                                                                    </td>
                                                                                                                                                                    <td width="20%"
                                                                                                                                                                        valign="middle"
                                                                                                                                                                        align="center">
                                                                                                                                                                        <a href="https://www.instagram.com/esportshive/"
                                                                                                                                                                            rel="noreferrer noopener"
                                                                                                                                                                            target="_blank"
                                                                                                                                                                            data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=http://astrogaming.com/instagram&amp;source=gmail&amp;ust=1607422678059000&amp;usg=AFQjCNHK1rgaQ_3XpwTrVe_GpzyxpH_Gxw"><img
                                                                                                                                                                                src="https://ci6.googleusercontent.com/proxy/i2Dom3tPsvbG60-8HKJtZSQRKWXMR2FzE2TC4pDV5KaNRMkiP_Gh3QkRDYX-7P6w5nVD947oOLMfL6BGNOYDis16LHAg4_8XUMg_j8AvrEwA5iAzwOCVLjNjZMwLlD63s3Ph0prFygigW-Abz6Y43h5t6fJMoEVGaGs=s0-d-e1-ft#https://drh.img.digitalriver.com/DRHM/Storefront/Site/logib2c/pb/images/notifications2019/ig_icon_b.png"
                                                                                                                                                                                alt="Instagram"
                                                                                                                                                                                style="display:block"
                                                                                                                                                                                width="26"
                                                                                                                                                                                border="0"></a>
                                                                                                                                                                    </td>
                                                                                                                                                                    <td width="20%"
                                                                                                                                                                        valign="middle"
                                                                                                                                                                        align="center">
                                                                                                                                                                        <a href="https://twitter.com/hive_gg"
                                                                                                                                                                            rel="noreferrer noopener"
                                                                                                                                                                            target="_blank"
                                                                                                                                                                            data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=http://astrogaming.com/twitter&amp;source=gmail&amp;ust=1607422678059000&amp;usg=AFQjCNFa8zQHnHEWVP28m0e5aGQUkwBbIw"><img
                                                                                                                                                                                src="https://ci6.googleusercontent.com/proxy/1oRkwQzGcPtvlWO1h4di_xpNDgOe3jbGANebzEReeLXPxf3kwuAqc-JBdWvQRqNfYhjPZeHIKBKWA7jyFgNj60kdCWJeoZTcZKkwhG-oD68KMCp-h5kGVxJDC732tXngO53IFLTvxd25PaXa7xiLkDXG_CG9bQavmMI=s0-d-e1-ft#https://drh.img.digitalriver.com/DRHM/Storefront/Site/logib2c/pb/images/notifications2019/tw_icon_b.png"
                                                                                                                                                                                alt="Twitter"
                                                                                                                                                                                style="display:block"
                                                                                                                                                                                width="25"
                                                                                                                                                                                border="0"></a>
                                                                                                                                                                    </td>
                                                                                                                                                                    <td width="20%"
                                                                                                                                                                        valign="middle"
                                                                                                                                                                        align="center">
                                                                                                                                                                        <a href="https://www.youtube.com/channel/UCYlF1yMI8dF_ZAu0K92XH5Q"
                                                                                                                                                                            rel="noreferrer noopener"
                                                                                                                                                                            target="_blank"
                                                                                                                                                                            data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=http://astrogaming.com/youtube&amp;source=gmail&amp;ust=1607422678059000&amp;usg=AFQjCNF3MweWsERKCGydK5WE2JXqJCJJpw"><img
                                                                                                                                                                                src="https://ci3.googleusercontent.com/proxy/CQUCTPBuBFtWhcIlwFQTIU4lvA0zxB99ShT2FkpG8vBu14kI2tiO1hHKIJzq4FxFmPPegsm7LvOTnOaD7NrURilwDs6HXBj-f3Ad0WtGhBVVc00SQO9PUl2dda0QV11DUSdh_iHF9KHEvPaABuguab4Q2sDr0pJKtW0=s0-d-e1-ft#https://drh.img.digitalriver.com/DRHM/Storefront/Site/logib2c/pb/images/notifications2019/yt_icon_b.png"
                                                                                                                                                                                alt="YouTube"
                                                                                                                                                                                style="display:block"
                                                                                                                                                                                width="25"
                                                                                                                                                                                border="0"></a>
                                                                                                                                                                    </td>
                                                                                                                                                                </tr>
                                                                                                                                                            </tbody>
                                                                                                                                                        </table>
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                            </tbody>
                                                                                                                        </table>
                                                                                                                        <table
                                                                                                                            width="100%"
                                                                                                                            cellspacing="0"
                                                                                                                            cellpadding="0"
                                                                                                                            border="0">
                                                                                                                            <tbody>
                                                                                                                                <tr>
                                                                                                                                    <td style="padding:25px 30px 12px 30px"
                                                                                                                                        valign="middle"
                                                                                                                                        align="left">
                                                                                                                                        <table
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="0"
                                                                                                                                            border="0"
                                                                                                                                            align="center">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td
                                                                                                                                                        align="center">
                                                                                                                                                        <table
                                                                                                                                                            cellspacing="0"
                                                                                                                                                            cellpadding="0"
                                                                                                                                                            border="0"
                                                                                                                                                            align="left">
                                                                                                                                                            <tbody>
                                                                                                                                                                <tr>
                                                                                                                                                                    <td style="padding:0px 10px 0px 0px;font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;font-size:14px;color:#2f3132;line-height:18px;font-weight:bold;border-right:2px solid #2f3132;white-space:nowrap"
                                                                                                                                                                        valign="middle"
                                                                                                                                                                        align="center">
                                                                                                                                                                        <a href="https://hive.gg/our-team/"
                                                                                                                                                                            style="color:#2f3132;text-decoration:none"
                                                                                                                                                                            rel="noreferrer noopener"
                                                                                                                                                                            target="_blank"
                                                                                                                                                                            data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=http://www.astrogaming.com/privacy&amp;source=gmail&amp;ust=1607422678059000&amp;usg=AFQjCNGJ5AfOqNoOCPcZpFc6CrC42suPLg">OUR TEAM</a>
                                                                                                                                                                    </td>
                                                                                                                                                                </tr>
                                                                                                                                                            </tbody>
                                                                                                                                                        </table>
                                                                                                                                                        <table
                                                                                                                                                            cellspacing="0"
                                                                                                                                                            cellpadding="0"
                                                                                                                                                            border="0"
                                                                                                                                                            align="left">
                                                                                                                                                            <tbody>
                                                                                                                                                                <tr>
                                                                                                                                                                    <td style="padding:0px 10px 0px 10px;font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;font-size:14px;color:#2f3132;line-height:18px;font-weight:bold;border-right:2px solid #2f3132;white-space:nowrap"
                                                                                                                                                                        valign="middle"
                                                                                                                                                                        align="center">
                                                                                                                                                                        <a href="https://hive.gg/contact-us/"
                                                                                                                                                                            style="color:#2f3132;text-decoration:none"
                                                                                                                                                                            rel="noreferrer noopener"
                                                                                                                                                                            target="_blank"
                                                                                                                                                                            data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=http://www.astrogaming.com/contact&amp;source=gmail&amp;ust=1607422678059000&amp;usg=AFQjCNH47i0u6IEIDsacC1Iztriu37Hq8g">CONTACT</a>
                                                                                                                                                                    </td>
                                                                                                                                                                </tr>
                                                                                                                                                            </tbody>
                                                                                                                                                        </table>
                                                                                                                                                        <table
                                                                                                                                                            cellspacing="0"
                                                                                                                                                            cellpadding="0"
                                                                                                                                                            border="0"
                                                                                                                                                            align="left">
                                                                                                                                                            <tbody>
                                                                                                                                                                <tr>
                                                                                                                                                                    <td style="padding:0px 0px 0px 10px;font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;font-size:14px;color:#2f3132;line-height:18px;font-weight:bold;white-space:nowrap"
                                                                                                                                                                        valign="middle"
                                                                                                                                                                        align="center">
                                                                                                                                                                        <a href="https://hive.gg/blog/"
                                                                                                                                                                            style="color:#2f3132;text-decoration:none"
                                                                                                                                                                            rel="noreferrer noopener"
                                                                                                                                                                            target="_blank"
                                                                                                                                                                            data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=http://www.astrogaming.com/terms&amp;source=gmail&amp;ust=1607422678059000&amp;usg=AFQjCNFdXGoB0PhnHaDVb93gWeWWwQCZ9g">LATEST NEWS</a>
                                                                                                                                                                    </td>
                                                                                                                                                                </tr>
                                                                                                                                                            </tbody>
                                                                                                                                                        </table>
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                            </tbody>
                                                                                                                        </table>
                                                                                                                        <table
                                                                                                                            width="100%"
                                                                                                                            cellspacing="0"
                                                                                                                            cellpadding="0"
                                                                                                                            border="0">
                                                                                                                            <tbody>
                                                                                                                                <tr>
                                                                                                                                    <td style="padding:0px 40px 30px 40px"
                                                                                                                                        align="left">
                                                                                                                                        <table
                                                                                                                                            width="100%"
                                                                                                                                            cellspacing="0"
                                                                                                                                            cellpadding="0"
                                                                                                                                            border="0">
                                                                                                                                            <tbody>
                                                                                                                                                <tr>
                                                                                                                                                    <td style="font-family:Geogrotesque,Arial,Verdana,Helvetica,sans-serif;font-size:12px;color:#2f3132;line-height:16px"
                                                                                                                                                        valign="top"
                                                                                                                                                        align="center">
                                                                                                                                                        ©
                                                                                                                                                        2020
                                                                                                                                                        Hive.
                                                                                                                                                        All
                                                                                                                                                        rights
                                                                                                                                                        reserved.
                                                                                                                                                        The
                                                                                                                                                        Hive
                                                                                                                                                        logo
                                                                                                                                                        and
                                                                                                                                                        other
                                                                                                                                                        Hive
                                                                                                                                                        marks
                                                                                                                                                        are
                                                                                                                                                        owned
                                                                                                                                                        by
                                                                                                                                                        Hive
                                                                                                                                                        and
                                                                                                                                                        may
                                                                                                                                                        be
																																						registered.
																																						<!--
																																						<br><br>
                                                                                                                                                        Logitech
                                                                                                                                                        Americas
                                                                                                                                                        Headquarters<br>
                                                                                                                                                        <a style="color:#2f3132;text-decoration:none"
                                                                                                                                                            rel="noreferrer noopener">7700
                                                                                                                                                            Gateway
                                                                                                                                                            Blvd.
                                                                                                                                                            Newark,
                                                                                                                                                            CA
                                                                                                                                                            94560
																																							USA</a><br><br>
-->
                                                                                                                                                    </td>
                                                                                                                                                </tr>
                                                                                                                                            </tbody>
                                                                                                                                        </table>
                                                                                                                                    </td>
                                                                                                                                </tr>
                                                                                                                            </tbody>
                                                                                                                        </table>
                                                                                                                    </td>
                                                                                                                </tr>
                                                                                                            </tbody>
                                                                                                        </table>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </font>
                                    </div>
                        </table>
            </table>
        </div>
    </div>
</body>